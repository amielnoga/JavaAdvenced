
public class IllegalBalance extends Exception {

	private static final long serialVersionUID = 1L;

	public IllegalBalance() {
		super();
	}

	public IllegalBalance(String s) {
		super(s);
	}
}
